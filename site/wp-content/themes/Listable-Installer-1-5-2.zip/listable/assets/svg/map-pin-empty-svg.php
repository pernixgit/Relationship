<svg width="48px" height="60px" viewBox="0 0 48 60" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:sketch="http://www.bohemiancoding.com/sketch/ns">
    <!-- Generator: Sketch 3.3.3 (12081) - http://www.bohemiancoding.com/sketch -->
    <title>path-2</title>
    <desc>Created with Sketch.</desc>
    <defs>
        <filter x="-50%" y="-50%" width="200%" height="200%" filterUnits="objectBoundingBox" id="filter-1">
            <feOffset dx="0" dy="1" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset>
            <feGaussianBlur stdDeviation="1" in="shadowOffsetOuter1" result="shadowBlurOuter1"></feGaussianBlur>
            <feColorMatrix values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.35 0" in="shadowBlurOuter1" type="matrix" result="shadowMatrixOuter1"></feColorMatrix>
            <feMerge>
                <feMergeNode in="shadowMatrixOuter1"></feMergeNode>
                <feMergeNode in="SourceGraphic"></feMergeNode>
            </feMerge>
        </filter>
    </defs>
    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" sketch:type="MSPage">
        <path d="M8.47133474,8.077269 C2.2753962,14.299523 0.55584737,23.2336414 3.19570658,30.9962607 C8.90326708,47.5714122 24.0560753,57.0608836 24.0560753,57.0608836 C24.0560753,57.0608836 39.0272756,47.6322053 44.7953721,31.2435407 C44.7953721,31.1827476 44.8559081,31.1219545 44.8559081,31.0578753 C47.5563033,23.2336414 45.8367544,14.299523 39.6408159,8.077269 C31.0512523,-0.54877633 17.0608983,-0.54877633 8.47133474,8.077269 L8.47133474,8.077269 Z M24,33.607735 C29.5228475,33.607735 34,29.1305825 34,23.607735 C34,18.0848875 29.5228475,13.607735 24,13.607735 C18.4771525,13.607735 14,18.0848875 14,23.607735 C14,29.1305825 18.4771525,33.607735 24,33.607735 L24,33.607735 Z" id="path-2" fill="#FFFFFF" filter="url(#filter-1)" sketch:type="MSShapeGroup"></path>
    </g>
</svg>
